<h1><?php echo $blast->get_title(); ?></h1>
