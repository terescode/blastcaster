<?php

if ( ! class_exists( 'BcAddBlastPostDao' ) ) {

	class BcAddBlastPostDao {

		/*
		function add_post( $title, $description, $image = null, $categories = array(), $tags = array() ) {

		}
		*/
	}

}
