<?php

if ( ! interface_exists( 'TcController' ) ) {

	interface TcController {
		function init();
	}

}
