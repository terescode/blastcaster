<?php

define( 'BC_PLUGIN_ID', 'blastcaster' );
define( 'BC_PLUGIN_DIR', plugin_dir_path( dirname( dirname( __FILE__ ) ) . DIRECTORY_SEPARATOR . BC_PLUGIN_ID ) );
